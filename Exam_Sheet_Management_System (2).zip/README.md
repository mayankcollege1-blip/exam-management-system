# College Exam Sheet Management System

A beginner-friendly Flask + SQLite project with exam sheet issue, collection, checking and marks management.

## Features
- Register exam sheet records (student, roll number, subject, exam date)
- Issue and collection status
- Save checker name and marks (0–100)
- Dashboard counts
- Delete records

## Run locally (Windows)
1. Install Python 3.10 or newer.
2. Extract this project folder.
3. Open terminal / CMD in this folder.
4. Create and activate virtual environment (optional):
   ```bash
   python -m venv .venv
   .venv\\Scripts\\activate
   ```
5. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
6. Run:
   ```bash
   python app.py
   ```
7. Open http://127.0.0.1:5000 in your browser.

The SQLite database `exam.db` is created automatically on first run.

## Upload to GitHub
1. Create a new repository on GitHub.
2. Upload these project files/folders (do not upload `exam.db` or `.venv`).
3. For local running, download/clone the repository and follow the steps above.

Note: GitHub is for storing and sharing code. To host a live Flask app, use a hosting platform that supports Python/Flask; GitHub Pages does not run Flask backend code.
