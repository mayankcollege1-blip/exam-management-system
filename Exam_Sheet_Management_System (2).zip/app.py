from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.secret_key = "change-this-secret-key"
DB = "exam.db"

def connect():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with connect() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS exam_sheets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_name TEXT NOT NULL,
            roll_no TEXT NOT NULL,
            subject TEXT NOT NULL,
            exam_date TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Issued',
            marks REAL,
            checked_by TEXT,
            created_at TEXT NOT NULL
        )""")

@app.route("/")
def index():
    with connect() as con:
        sheets = con.execute("SELECT * FROM exam_sheets ORDER BY id DESC").fetchall()
        total = con.execute("SELECT COUNT(*) FROM exam_sheets").fetchone()[0]
        issued = con.execute("SELECT COUNT(*) FROM exam_sheets WHERE status='Issued'").fetchone()[0]
        collected = con.execute("SELECT COUNT(*) FROM exam_sheets WHERE status='Collected'").fetchone()[0]
        checked = con.execute("SELECT COUNT(*) FROM exam_sheets WHERE status='Checked'").fetchone()[0]
    return render_template("index.html", sheets=sheets, total=total, issued=issued, collected=collected, checked=checked)

@app.route("/add", methods=["POST"])
def add_sheet():
    name=request.form.get("student_name","").strip()
    roll=request.form.get("roll_no","").strip()
    subject=request.form.get("subject","").strip()
    exam_date=request.form.get("exam_date","").strip()
    if not all([name,roll,subject,exam_date]):
        flash("Please fill all fields.")
        return redirect(url_for("index"))
    with connect() as con:
        con.execute("INSERT INTO exam_sheets (student_name,roll_no,subject,exam_date,status,created_at) VALUES (?,?,?,?,?,?)",
                    (name,roll,subject,exam_date,"Issued",datetime.now().strftime("%Y-%m-%d %H:%M")))
    flash("Exam sheet added and marked as Issued.")
    return redirect(url_for("index"))

@app.route("/status/<int:sheet_id>/<status>", methods=["POST"])
def update_status(sheet_id,status):
    if status not in ["Issued","Collected"]:
        flash("Invalid status.")
        return redirect(url_for("index"))
    with connect() as con:
        con.execute("UPDATE exam_sheets SET status=? WHERE id=? AND marks IS NULL",(status,sheet_id))
    flash("Sheet status updated.")
    return redirect(url_for("index"))

@app.route("/check/<int:sheet_id>", methods=["POST"])
def check_sheet(sheet_id):
    checker=request.form.get("checked_by","").strip()
    marks=request.form.get("marks","").strip()
    try:
        mark=float(marks)
        if mark < 0 or mark > 100: raise ValueError
    except ValueError:
        flash("Marks must be between 0 and 100.")
        return redirect(url_for("index"))
    if not checker:
        flash("Enter checker name.")
        return redirect(url_for("index"))
    with connect() as con:
        con.execute("UPDATE exam_sheets SET status='Checked', marks=?, checked_by=? WHERE id=?",
                    (mark,checker,sheet_id))
    flash("Checking completed and marks saved.")
    return redirect(url_for("index"))

@app.route("/delete/<int:sheet_id>", methods=["POST"])
def delete_sheet(sheet_id):
    with connect() as con:
        con.execute("DELETE FROM exam_sheets WHERE id=?",(sheet_id,))
    flash("Record deleted.")
    return redirect(url_for("index"))

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
